#!/bin/bash
# threat_hunt_full.sh
# Comprehensive threat hunting script compatible with both Rocky Linux and Ubuntu.
# Must be run as root.
#
# This script performs:
# 1. Lists running services and established TCP connections.
# 1.5 Detects running .service files that aren’t default.
# 2. Displays scheduled tasks (system-wide crontab, /etc/cron.d, user crontabs, systemd timers).
# 3. Searches for suspicious files and script content.
# 4. Checks PAM configuration (displays auth files and searches for abnormal references).
# 5. Performs heuristic reverse shell detection (both established and listening)
#    and prints any suspect processes.
# 6. Checks binary integrity using debsums (if available) or rpm (runs in background and logs to /root/binary_integrity.txt).
# 7. Searches for system binaries with suspicious names.
# 8. Backs up all cron jobs (system and user crontabs) to /root/cron.txt and deletes them.
# 9. Scans /etc/shadow for accounts that either have no password set or appear active.
# 10. Deletes all user crontabs for every user except for "blackteam".

###############################
# Preliminary: Choose netstat or ss
###############################
if command -v netstat >/dev/null 2>&1; then
    EST_CMD="netstat -tnp"
    LIST_CMD="netstat -tnlp"
else
    EST_CMD="ss -tnp"
    LIST_CMD="ss -tnlp"
fi

###############################
# Part 1: System Services & Network
###############################
echo "=== Running Services ==="
running_services=$(systemctl list-units --type=service --state=running --no-pager --no-legend | awk '{print $1}')
echo "$running_services"
echo ""

echo "=== Established TCP Connections ==="
$EST_CMD | grep ESTABLISHED
echo ""

###############################
# Part 1.5: Non-default Running Services
###############################
default_services=(
  "systemd-journald.service"
  "systemd-udevd.service"
  "systemd-logind.service"
  "NetworkManager.service"
  "network-manager.service"
  "firewalld.service"
  "crond.service"
  "cron.service"
  "sshd.service"
  "ssh.service"
  "rsyslog.service"
  "polkit.service"
  "polkit-1.service"
  "chronyd.service"
  "chrony.service"
  "auditd.service"
  "dbus.service"
  "systemd-timesyncd.service"
  "systemd-resolved.service"
)

echo "=== Non-default Running Services ==="
for service in $running_services; do
  found=0
  for def in "${default_services[@]}"; do
    if [ "$service" == "$def" ]; then
      found=1
      break
    fi
  done
  if [ $found -eq 0 ]; then
    echo -e "\033[0;31m$service\033[0m"
  fi
done
echo ""

###############################
# Part 2: Scheduled Tasks (Crontabs & Timers)
###############################
echo "=== System-Wide Crontab (/etc/crontab) ==="
if [ -f /etc/crontab ]; then
  cat /etc/crontab
else
  echo "/etc/crontab not found."
fi
echo ""

echo "=== Cron.d Files (/etc/cron.d) ==="
if [ -d /etc/cron.d ]; then
  for file in /etc/cron.d/*; do
    [ -e "$file" ] || continue
    echo "---- $file ----"
    cat "$file"
    echo "----------------------------------------"
  done
else
  echo "/etc/cron.d directory not found."
fi
echo ""

echo "=== Cron Periodic Jobs (daily, hourly, weekly, monthly) ==="
for dir in /etc/cron.daily /etc/cron.hourly /etc/cron.weekly /etc/cron.monthly; do
  if [ -d "$dir" ]; then
    echo "---- Directory: $dir ----"
    ls -la "$dir"
    echo "----------------------------------------"
  else
    echo "$dir not found."
  fi
done
echo ""

echo "=== User Crontabs ==="
for user in $(cut -d: -f1 /etc/passwd); do
  echo "---- Crontab for user: $user ----"
  crontab -l -u "$user" 2>/dev/null || echo "No crontab for $user."
  echo "----------------------------------------"
done
echo ""

echo "=== Systemd Timers ==="
systemctl list-timers --all --no-pager
echo ""

###############################
# Part 3: Suspicious Files & Script Content
###############################
echo "=== Suspicious Files in /tmp & /var/tmp ==="
find /tmp /var/tmp -type f \( -perm -o+w -o -perm -4000 -o -perm -2000 \) -exec ls -la {} \; 2>/dev/null
echo ""

echo "=== Suspicious Script Content ('eval(') in /home & /etc ==="
grep -R "eval(" /home /etc 2>/dev/null
echo ""

###############################
# Part 4: PAM Configuration Checks
###############################
echo "=== PAM Configuration (Auth) ==="
if [ -f /etc/pam.d/password-auth ]; then
  cat /etc/pam.d/password-auth
elif [ -f /etc/pam.d/common-auth ]; then
  cat /etc/pam.d/common-auth
else
  echo "No PAM auth config file found."
fi
echo ""

echo "=== PAM Configuration (Password/System Auth) ==="
if [ -f /etc/pam.d/system-auth ]; then
  cat /etc/pam.d/system-auth
elif [ -f /etc/pam.d/common-password ]; then
  cat /etc/pam.d/common-password
else
  echo "No PAM system-auth config file found."
fi
echo ""

echo "=== Abnormal PAM References ==="
echo "[*] Extracting all file paths referenced in /etc/pam.d/..."
paths=$(grep -R -o -E '/[^[:space:]]+' /etc/pam.d/ 2>/dev/null | sort -u)
normal_dirs=(
  "/bin/"
  "/sbin/"
  "/usr/bin/"
  "/usr/sbin/"
  "/lib/"
  "/lib64/"
  "/usr/lib/"
  "/usr/lib64/"
)
echo "[*] Checking for file paths not in normal directories:"
echo "$paths" | while read -r path; do
  abnormal=1
  for norm in "${normal_dirs[@]}"; do
    if [[ "$path" == $norm* ]]; then
      abnormal=0
      break
    fi
  done
  if [ $abnormal -eq 1 ]; then
    echo "$path"
  fi
done
echo ""

###############################
# Part 5: Reverse Shell Detection (Final Section)
###############################
echo "=== Heuristic Reverse Shell Search (Final Section) ==="
candidate_established=()
candidate_listening=()

echo "[*] Checking bash processes for established network connections..."
for pid in $(pgrep -x bash); do
  conns=$($EST_CMD 2>/dev/null | grep "$pid/" | grep ESTABLISHED)
  if [ -n "$conns" ]; then
    echo "Possible reverse shell candidate (bash, established):"
    ps -p "$pid" -o pid,cmd
    echo "$conns"
    candidate_established+=($pid)
    echo "----------------------------------------"
  fi
done

echo "[*] Checking nc processes for established network connections..."
for pid in $(pgrep -x nc); do
  conns=$($EST_CMD 2>/dev/null | grep "$pid/" | grep ESTABLISHED)
  if [ -n "$conns" ]; then
    echo "Possible reverse shell candidate (nc, established):"
    ps -p "$pid" -o pid,cmd
    echo "$conns"
    candidate_established+=($pid)
    echo "----------------------------------------"
  fi
done

echo "[*] Checking bash processes for listening connections..."
for pid in $(pgrep -x bash); do
  listening=$($LIST_CMD 2>/dev/null | grep "$pid/" | grep LISTEN)
  if [ -n "$listening" ]; then
    echo "Possible listening reverse shell candidate (bash):"
    ps -p "$pid" -o pid,cmd
    echo "$listening"
    candidate_listening+=($pid)
    echo "----------------------------------------"
  fi
done

echo "[*] Checking nc processes for listening connections..."
for pid in $(pgrep -x nc); do
  listening=$($LIST_CMD 2>/dev/null | grep "$pid/" | grep LISTEN)
  if [ -n "$listening" ]; then
    echo "Possible listening reverse shell candidate (nc):"
    ps -p "$pid" -o pid,cmd
    echo "$listening"
    candidate_listening+=($pid)
    echo "----------------------------------------"
  fi
done

echo "Potential reverse shell candidate process IDs:"
echo "Established: ${candidate_established[@]}"
echo "Listening: ${candidate_listening[@]}"
echo ""

###############################
# Part 6: Binary Integrity Check (Background)
###############################
echo ""
echo "=== Binary Integrity Check ==="
if command -v debsums >/dev/null 2>&1; then
    echo "[*] Running debsums -s in background; output to /root/binary_integrity.txt (this may take a while)..."
    debsums -s > /root/binary_integrity.txt 2>&1 &
elif command -v rpm >/dev/null 2>&1; then
    echo "[*] Running rpm -Va in background; output to /root/binary_integrity.txt (this may take a while)..."
    rpm -Va > /root/binary_integrity.txt 2>&1 &
else
    echo "Neither debsums nor rpm command found. Cannot check binary integrity."
fi

###############################
# Part 7: Check System Binaries for Suspicious Names
###############################
echo ""
echo "=== Suspicious Named Files ==="
find / -type f \( -name "*redteam*" -o -name "red_herring" -o -name "dropbear" -o -name "watershell" -o -name "shell" -o -name "shelly" \) 2>/dev/null
echo ""

###############################
# Part 8: Backup and Delete All Cron Jobs (System and User Crontabs)
###############################
echo ""
echo "=== Backup and Delete All Cron Jobs (System and User Crontabs) ==="
BACKUP_FILE="/root/cron.txt"
echo "Backing up all cron jobs to $BACKUP_FILE"
echo "Backup created on $(date)" > "$BACKUP_FILE"
echo "----------------------------------------" >> "$BACKUP_FILE"

# Backup and delete /etc/crontab.
echo "Processing /etc/crontab..."
if [ -f /etc/crontab ]; then
    echo "----- /etc/crontab -----" >> "$BACKUP_FILE"
    cat /etc/crontab >> "$BACKUP_FILE"
    rm -f /etc/crontab && echo "Deleted /etc/crontab"
else
    echo "/etc/crontab not found."
fi
echo "----------------------------------------" >> "$BACKUP_FILE"

# Backup and delete files in /etc/cron.d.
echo "Processing /etc/cron.d..."
if [ -d /etc/cron.d ]; then
    for f in /etc/cron.d/*; do
        if [ -f "$f" ]; then
            echo "----- $f -----" >> "$BACKUP_FILE"
            cat "$f" >> "$BACKUP_FILE"
            rm -f "$f" && echo "Deleted $f"
            echo "----------------------------------------" >> "$BACKUP_FILE"
        fi
    done
else
    echo "/etc/cron.d directory not found."
fi

# Backup and delete files in cron periodic directories.
for dir in /etc/cron.daily /etc/cron.hourly /etc/cron.weekly /etc/cron.monthly; do
    echo "Processing $dir..."
    if [ -d "$dir" ]; then
        for f in "$dir"/*; do
            if [ -f "$f" ]; then
                echo "----- $f -----" >> "$BACKUP_FILE"
                cat "$f" >> "$BACKUP_FILE"
                rm -f "$f" && echo "Deleted $f"
                echo "----------------------------------------" >> "$BACKUP_FILE"
            fi
        done
    else
        echo "$dir not found."
    fi
done

# Backup user crontabs.
echo "Processing user crontabs..."
echo "----- User Crontabs -----" >> "$BACKUP_FILE"
for user in $(cut -d: -f1 /etc/passwd); do
    echo "----- Crontab for user: $user -----" >> "$BACKUP_FILE"
    crontab -l -u "$user" 2>/dev/null >> "$BACKUP_FILE"
done

echo "Backup complete. All system cron jobs and user crontabs have been backed up to $BACKUP_FILE."
echo ""

###############################
# Part 10: Delete All User Crontabs Except for 'blackteam'
###############################
echo "=== Deleting All User Crontabs (Except for 'blackteam') ==="
for user in $(cut -d: -f1 /etc/passwd); do
  if [ "$user" != "blackteam" ]; then
    echo "Deleting crontab for user: $user"
    crontab -r -u "$user" 2>/dev/null
  else
    echo "Preserving crontab for user: blackteam"
  fi
done

###############################
# Part 9: Check /etc/shadow for Suspicious User Accounts
###############################
echo "=== Suspicious /etc/shadow Entries ==="
echo "[*] Listing accounts with no password set or with active password hashes (i.e. not locked):"
awk -F: '{ if($2 == "" || $2 !~ /^(\*|!)/) print $0 }' /etc/shadow
echo ""

echo ""
echo "Threat hunting completed."
